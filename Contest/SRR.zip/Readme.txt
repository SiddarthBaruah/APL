Team
============================
Name1: Siddarth Baruah(EE21B128)
Name2: Rohan Kuman(EE21B113)

Firstly we imported the array,
Then sorted the array, mapped with the initial position
Then found out total sum
We added the numbers in sorted way until we found the point when it reaches just above sum/2.
Thus we mapped back the the numbers and divided the group in 1 and 0